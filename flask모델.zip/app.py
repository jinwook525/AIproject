from flask import Flask, jsonify
import torch
import preprocessing  # 전처리 모듈
import model  # AI 모델 모듈
import logging
import numpy as np

app = Flask(__name__)

@app.route("/")
def home():
    return jsonify({"message": "Flask API is running!"})

logging.basicConfig(filename="debug_log.txt", level=logging.DEBUG, format="%(asctime)s - %(levelname)s - %(message)s")

# ✅ StandardScaler 불러오기
lat_lon_scaler = preprocessing.get_lat_lon_scaler()

@app.route("/predict", methods=["GET"])
def predict():
    """ 최신 데이터 불러와 실시간 예측 수행 """
    processed_data = preprocessing.preprocess()  # 전처리 수행

    if processed_data is None:
        return jsonify({"error": "No valid data available"}), 400

    print("✅ Flask에서 받은 processed_data의 mmsi 목록:", list(processed_data.keys()))

    predictions = {}
    for mmsi, tensor in processed_data.items():
        # 모델 예측 수행
        pred = model.predict(tensor)

        if isinstance(pred, list):
            pred = np.array(pred)
        elif isinstance(pred, torch.Tensor):
            pred = pred.detach().cpu().numpy()

        if pred.ndim == 1:
            pred = pred.reshape(1, -1)

        pred[:, 0:2] = lat_lon_scaler.inverse_transform(pred[:, 0:2])

        predictions[mmsi] = {
            "mmsi": mmsi,
            "prediction": pred.tolist(),
        }

    return jsonify({"predictions": predictions})

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
